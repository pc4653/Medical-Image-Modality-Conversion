#>>> config
#Namespace(a_grayscale=False, b_grayscale=False, batch_size=200, beta1=0.5, beta2=0.999, cnn_type=0, d_num_layer=5, data_dir='data', data_path='data/MRI', #dataset='MRI', fc_hidden_dim=128, g_num_layer=3, input_scale_size=64, is_train=False, load_path='logs/MRI_2017-11-18_22-01-27', log_dir='logs', log_level='INFO', #log_step=50, loss='log_prob', lr=0.0002, max_step=500000, model_dir='logs/MRI_2017-11-18_22-01-27', num_gpu=1, num_log_samples=3, num_worker=12, optimizer='adam', #random_seed=123, sample_per_image=64, save_step=500, skip_pix2pix_processing=False, test_data_path=None, weight_decay=0.0001)
from models import *
from data_loader import get_loader
import os
data_path = config.data_path
batch_size = config.batch_size
a_data_loader, b_data_loader = get_loader(
            data_path, batch_size, config.input_scale_size,
            config.num_worker, config.skip_pix2pix_processing)

path = os.path.join(config.load_path, 'G_AB_49999.pth')

conv_dims, deconv_dims = [64, 128, 256, 512], [256, 128, 64]
a_height, a_width, a_channel = a_data_loader.shape
b_height, b_width, b_channel = b_data_loader.shape
#G_AB = GeneratorCNN(a_channel, b_channel, conv_dims, deconv_dims, config.num_gpu)
G_AB = GeneratorCNN(a_channel, b_channel, conv_dims, deconv_dims, 1)
G_AB.load_state_dict(torch.load(path))