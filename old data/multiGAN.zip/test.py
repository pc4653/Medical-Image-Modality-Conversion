import os
import numpy as np
from glob import glob
from PIL import Image
import torchvision.utils as vutils
import torch
from torchvision import transforms
import scipy.misc
from config import get_config
from utils import prepare_dirs_and_logger, save_config
from torch.autograd import Variable
from torch import nn
import torch.nn.functional as F

def save_torch_img(var):
    gen_img = var[:,0,:,:]
    seg_img = var[:,1,:,:]
    out_img = torch.cat((gen_img, seg_img),0)
    out_img = out_img.numpy()
    for i in range(20):
        scipy.misc.imsave(str(i) + '.jpg', out_img[i])



def makedirs(path):
    if not os.path.exists(path):
        os.makedirs(path)

class Dataset(torch.utils.data.Dataset):
    def __init__(self, root, scale_size, data_type):
        self.root = root
        if not os.path.exists(self.root):
            raise Exception("[!] {} not exists.".format(root))
        self.name = os.path.basename(root)
        self.paths = glob(os.path.join(self.root, '{}/*'.format(data_type)))
        if len(self.paths) == 0:
            raise Exception("No images are found in {}".format(self.root))
        self.shape = list(np.load(self.paths[0]).shape)
        
    def __getitem__(self, index):
        data = np.load(self.paths[index])
        return torch.from_numpy(data).float()
    def __len__(self):
        return len(self.paths)
	
class DiscriminatorCNN(nn.Module):
    def __init__(self, input_channel, output_channel, hidden_dims, num_gpu):
        super(DiscriminatorCNN, self).__init__()
        self.num_gpu = num_gpu
        self.layers = []
        prev_dim = hidden_dims[0]
        self.layers.append(nn.Conv2d(input_channel, prev_dim, 4, 2, 1, bias=False))
        self.layers.append(nn.LeakyReLU(0.2, inplace=True))
        for out_dim in hidden_dims[1:]:
            self.layers.append(nn.Conv2d(prev_dim, out_dim, 4, 2, 1, bias=False))
            self.layers.append(nn.BatchNorm2d(out_dim))
            self.layers.append(nn.LeakyReLU(0.2, inplace=True))
            prev_dim = out_dim
        #this is where dim of pix / 2^len(conv_dim) gets compress to 1 value for discrimination
        self.layers.append(nn.Conv2d(prev_dim, output_channel, 30, 1, 0, bias=False))
        self.layers.append(nn.Sigmoid())
        self.layer_module = nn.ModuleList(self.layers)
    def main(self, x):
        out = x
        for layer in self.layer_module:
            out = layer(out)
        return out.view(out.size(0), -1)
    def forward(self, x):
        return self.main(x)	
	
t1_data_set = Dataset('dataset', 240, 't1')
t2_data_set = Dataset('dataset', 240, 't2')
t1_data_loader = torch.utils.data.DataLoader(dataset=t1_data_set,
                                             batch_size=10,
                                             shuffle=True,
                                             num_workers=1)
t2_data_loader = torch.utils.data.DataLoader(dataset=t2_data_set,
                                             batch_size=10,
                                             shuffle=True,
                                             num_workers=1)
t1_data_loader.shape = t1_data_set.shape
t2_data_loader.shape = t2_data_set.shape

#config = get_config()

#trainer = Trainer(config, t1_data_loader, t2_data_loader)





test_set = iter(t1_data_loader)
a = test_set.next()
save_torch_img(a)
img = a[:,0,:,:]
seg = a[:,1,:,:]

img_ = torch.zeros((10,1,240,240))
for i in range(10):
        img_[i,0,:,:] = img[i,:,:]
            
seg_ = torch.zeros((10,1,240,240))
for i in range(10):
        seg_[i,0,:,:] = seg[i,:,:]

img_ = Variable(img_)
seg_ = Variable(seg_)
conv_dims, deconv_dims = [64, 128, 256], [128, 64]

D = DiscriminatorCNN(1,1,conv_dims,1)

D.cuda()
