import os
import numpy as np
from glob import glob
from PIL import Image

import torch
from torchvision import transforms


def makedirs(path):
    if not os.path.exists(path):
        os.makedirs(path)

class Dataset(torch.utils.data.Dataset):
    def __init__(self, root, scale_size, data_type):
        self.root = root
        if not os.path.exists(self.root):
            raise Exception("[!] {} not exists.".format(root))
        self.name = os.path.basename(root)
        self.paths = glob(os.path.join(self.root, '{}/*'.format(data_type)))
        if len(self.paths) == 0:
            raise Exception("No images are found in {}".format(self.root))
        self.shape = list(np.load(self.paths[0]).shape)
        
    def __getitem__(self, index):
        data = np.load(self.paths[index])
        return torch.from_numpy(data).float()
    def __len__(self):
        return len(self.paths)

def get_loader(root, batch_size, scale_size, num_workers=1,
               skip_pix2pix_processing=False, shuffle=True):
    t1_data_set, t2_data_set = \
        Dataset(root, scale_size, "flair"), \
        Dataset(root, scale_size, "t2")
    t1_data_loader = torch.utils.data.DataLoader(dataset=t1_data_set,
                                                batch_size=batch_size,
                                                shuffle=True,
                                                num_workers=num_workers)
    t2_data_loader = torch.utils.data.DataLoader(dataset=t2_data_set,
                                                batch_size=batch_size,
                                                shuffle=True,
                                                num_workers=num_workers)
    t1_data_loader.shape = t1_data_set.shape
    t2_data_loader.shape = t2_data_set.shape

    return t1_data_loader, t2_data_loader
